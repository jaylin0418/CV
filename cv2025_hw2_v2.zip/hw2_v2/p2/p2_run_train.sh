### example for running the python files, you don't have to submit this file

### Training (only you will run this)
python3 p2_train.py --dataset_dir ../hw2_data/p2_data/